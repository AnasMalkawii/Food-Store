
document.querySelector('.menu').addEventListener('click', ()=>{
    document.querySelectorAll('.target').forEach((e)=>{
        e.classList.toggle('navbarChange');
    });
});



const icons = document.querySelectorAll('.section-1-icons i');
var i = 1;

setInterval(() =>{
    i++;
    const iconChange = document.querySelector('.section-1-icons .change');
    iconChange.classList.remove('change');
    if(i > icons.length){
        icons[0].classList.add('change');
        i = 1;
    }else{
        iconChange.nextElementSibling.classList.add('change');
    }
}, 2500);